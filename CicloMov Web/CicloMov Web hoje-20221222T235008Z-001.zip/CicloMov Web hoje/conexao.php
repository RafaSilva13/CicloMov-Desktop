<?php
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "bd_estacionamento";

    // Create connection
    $conn = mysqli_connect($servername, $username, $password, $dbname); 
?>